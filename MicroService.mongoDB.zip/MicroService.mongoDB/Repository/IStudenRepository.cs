﻿using MicroService.mongoDB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Repository
{
   public  interface IStudenRepository
    {
        List<Student> GetAll();

        Student GetById(string Id);

        void Create(Student student);

        void Update(Student student);

        void Remove(string Id);

    }
}
