﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Repository
{
    public interface IStudentDataBaseSettings
    {
       public  string CollectionName { set; get; }
        public string ConnectionString { set; get; }
        public string DataBaseName { set; get; }
    }
}
