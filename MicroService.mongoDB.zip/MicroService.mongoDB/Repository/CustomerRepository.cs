﻿using MicroService.mongoDB.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Repository
{
    public class CustomerRepository : ICustomerRepository
    {
        public IMongoCollection<Customer> _customers { get; }
        public CustomerRepository(IMongoClient mongoClient)
        {
            var dataBase = mongoClient.GetDatabase("Banking");
            _customers = dataBase.GetCollection<Customer>("Customer");
        }

        public List<Customer> GetAll()
        {
           return  _customers.Find(FilterDefinition<Customer>.Empty).ToList();
        }
    }
}
