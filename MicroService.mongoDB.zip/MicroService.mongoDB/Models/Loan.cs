﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Models
{
    public class Loan
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { set; get; }

        [BsonElement("loanname")]
        public string Loanname { set; get; }
        [BsonElement("loanaccount")]
        public string LoanAccount { set; get; }
        [BsonElement("loannumber")]
        public string LoanNumber { set; get; }

    }
}
