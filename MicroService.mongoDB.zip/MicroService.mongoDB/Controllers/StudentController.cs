﻿using MicroService.mongoDB.Models;
using MicroService.mongoDB.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudenRepository _studenRepository;
        private readonly ICustomerRepository _customerRepository;
        public StudentController(IStudenRepository studenRepository,ICustomerRepository customerRepository)
        {
            _studenRepository = studenRepository;
            _customerRepository = customerRepository;
        }

        [HttpGet()]
        public ActionResult<List<Student>> GetAll()
        {
            var customers = _customerRepository.GetAll();
            return Ok(_studenRepository.GetAll());
        }

        [Route("")]
        [HttpPost]
        public ActionResult Create([FromBody] Student student)
        {

            if (student != null)
            {
                _studenRepository.Create(student);
                return Ok("Added Succesfully");
            } else
                return BadRequest();

        }

        //[HttpGet("{id?}")]
        //[Route({"Id"})] 
        [HttpGet("RetrieveById/{id}")]
        public ActionResult<Student> RetrieveById(string  id)
        {

            if (id != null)
            {
                return Ok(_studenRepository.GetById(id));
            }
            else
                return BadRequest();

        }

        [HttpPost("Update")]
        public ActionResult Update([FromBody] Student student)
        {
            var existingStudent = _studenRepository.GetById(student.Id);
            if (existingStudent != null)
            {
                _studenRepository.Update(student);
            }

            return Ok();

        }

        [HttpPost("Delete")]
        public ActionResult Delete(string Id)
        {

            _studenRepository.Remove(Id);
            return Ok();


        }
    }
}
