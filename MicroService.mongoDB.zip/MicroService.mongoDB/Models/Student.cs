﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Models
{
    public class Student
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { set; get; }

        [BsonElement("studentname")]
        public string Studentname { set; get; }
        [BsonElement("location")]
        public string Location { set; get; }
        [BsonElement("collegename")]
        public string Collegename { set; get; }

    }
}
