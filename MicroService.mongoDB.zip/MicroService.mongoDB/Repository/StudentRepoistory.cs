﻿using MicroService.mongoDB.Models;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Repository
{
    public class StudentRepoistory : IStudenRepository
    {
        public IMongoCollection<Student> _students { get; }
        public StudentRepoistory(IStudentDataBaseSettings settings, IMongoClient mongoClient)
        {
            var dataBase = mongoClient.GetDatabase(settings.DataBaseName);
            _students = dataBase.GetCollection<Student>(settings.CollectionName);
        }

        public void Create(Student student)
        {
            _students.InsertOne(student);
        }

        public List<Student> GetAll()
        {
            
            return _students.Find(FilterDefinition<Student>.Empty).ToList();
           
        }

        public Student GetById(string Id)
        {
            return _students.Find(x => x.Id == Id).FirstOrDefault();
        }

        public void Remove(string Id)
        {
            _students.DeleteOne(x => x.Id == Id);
        }

        public void Update(Student student)
        {
            _students.ReplaceOne(x => x.Id == student.Id, student);
        }
    }
}
