﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroService.mongoDB.Repository
{
    public class StudentDataBaseSettings : IStudentDataBaseSettings
    {
        public string CollectionName { get; set; } = "StudentCollection";
        //public string ConnectionString { get; set; } = "mongodb+srv://muraliragam:murali123@cluster0.pdwgm.mongodb.net/test";

        public string ConnectionString { get; set; } = "mongodb+srv://Krishna:Krish@3096@cluster0.0um20.mongodb.net/test";
        public string DataBaseName { get ; set ; } = "StudentsDB";
    }
}
